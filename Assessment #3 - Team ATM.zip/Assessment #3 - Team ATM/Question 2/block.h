#ifndef __BLOCK_H__
#define __BLOCK_H__

extern const uint16_t blocks[10][10*10];

#endif