#ifndef __IMAGE_DATA_H__
#define __IMAGE_DATA_H__

extern uint8_t image[240*320*3];
extern uint8_t image2[240*320*3];
extern uint8_t image3[240*320*3];

#endif